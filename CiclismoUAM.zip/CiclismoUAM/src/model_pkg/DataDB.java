/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model_pkg;

import java.util.Date;

/**
 *
 * @author araag
 */
public class DataDB {
    private int id_usuario;
    private String nombre_usuario;
    private String identificacion;
    private String contraseña;
    private String correo;
    
    
    private int id_ruta;
    private String inicio_ruta;
    private String final_ruta;
    private Date fecha_inicio;
    private Date fecha_final;
    private float km;
    private float tiempo;
    private String novedad;
    private String descripcion;
    private int id_ciclista;

    public DataDB() {
        this.id_usuario = 0;
        this.nombre_usuario = "";
        this.identificacion = "";
        this.contraseña = "";
        this.correo = "";
        this.id_ruta = 0;
        this.inicio_ruta = "";
        this.final_ruta = "";
        this.fecha_inicio = new Date();
        this.fecha_final = new Date();
        this.km = 0;
        this.tiempo = 0;
        this.novedad="";
        this.descripcion = "";
        this.id_ciclista=0;
    }

    public int getId_ciclista() {
        return id_ciclista;
    }

    public void setId_ciclista(int id_ciclista) {
        this.id_ciclista = id_ciclista;
    }

    public String getNovedad() {
        return novedad;
    }

    public void setNovedad(String novedad) {
        this.novedad = novedad;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public int getId_ruta() {
        return id_ruta;
    }

    public void setId_ruta(int id_ruta) {
        this.id_ruta = id_ruta;
    }

    public String getInicio_ruta() {
        return inicio_ruta;
    }

    public void setInicio_ruta(String inicio_ruta) {
        this.inicio_ruta = inicio_ruta;
    }

    public String getFinal_ruta() {
        return final_ruta;
    }

    public void setFinal_ruta(String final_ruta) {
        this.final_ruta = final_ruta;
    }

    public Date getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(Date fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public Date getFecha_final() {
        return fecha_final;
    }

    public void setFecha_final(Date fecha_final) {
        this.fecha_final = fecha_final;
    }

    public float getKm() {
        return km;
    }

    public void setKm(float km) {
        this.km = km;
    }

    public float getTiempo() {
        return tiempo;
    }

    public void setTiempo(float tiempo) {
        this.tiempo = tiempo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
    
    
    
}
