package model_pkg;

import java.util.ArrayList;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author estuam
 */
public class DataModelDB {
    
    Pool conexion = new Pool();
    Connection conectar = null;
    PreparedStatement pst;
    ResultSet rs;
    DataDB datosDB;
    
    //Método de consulta de Hospitales ...
    public ArrayList<DataDB>getUsuarios(int id_usuario){
        ArrayList usuario_list = new ArrayList<>();
        
        try{
            conectar = conexion.initializeDataSource().getConnection();
            if(conectar != null){
                System.out.println("Conexión Exitosa!");
                String sql = "SELECT id, usuario, identificacion, contrasena, correo FROM tb_usuario";
                pst = conectar.prepareStatement(sql);
              
                //El resultSet almanecara el resultado de la ejecución del Query ...
                rs = pst.executeQuery();
                while(rs.next()){
                    datosDB = new DataDB();
                    datosDB.setId_usuario(rs.getInt("id"));
                    datosDB.setNombre_usuario(rs.getString("usuario"));
                    datosDB.setIdentificacion(rs.getString("identificacion"));
                    datosDB.setContraseña(rs.getString("contrasena"));
                    datosDB.setCorreo("correo");
                    usuario_list.add(datosDB);
                }
            }else{
                JOptionPane.showMessageDialog(null, "No se encontró información de Usuarios");
            }
        }catch(SQLException e){
            System.out.println(e);
        }finally{
            try{
                conectar.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, "No se pudo cerrar conexión " + e);
            }
        }  
        return usuario_list;    
    }
    
    public ArrayList<DataDB>getRutas(int id_rutas){
        ArrayList rutas_list = new ArrayList<>();
        
        try{
            System.out.println("Hola");
            conectar = conexion.initializeDataSource().getConnection();
            if(conectar != null){
                System.out.println("Conexión Exitosa!");
                String sql = "SELECT * FROM `tb_ruta` WHERE id_usuario= '"+id_rutas+"'";

                pst = conectar.prepareStatement(sql);
                
                //El resultSet almanecara el resultado de la ejecución del Query ...
                rs = pst.executeQuery();
                
                
                while(rs.next()){
                    datosDB = new DataDB();
                    datosDB.setId_ruta(rs.getInt("id"));
                    datosDB.setInicio_ruta(rs.getString("inicio_ruta"));
                    datosDB.setFinal_ruta(rs.getString("final_ruta"));
                    datosDB.setFecha_inicio(rs.getDate("fecha_inicio"));
                    datosDB.setFecha_final(rs.getDate("fecha_final"));
                    datosDB.setKm(rs.getFloat("km"));
                    datosDB.setTiempo(rs.getFloat("tiempo"));
                    datosDB.setNovedad(rs.getString("novedad"));
                    datosDB.setDescripcion(rs.getString("descripcion"));
                    rutas_list.add(datosDB);
                }
            }else{
                JOptionPane.showMessageDialog(null, "No se encontró información de Rutas");
            }
        }catch(SQLException e){
            System.out.println(e);
        }finally{
            try{
                conectar.close();
            }catch(SQLException e){
                JOptionPane.showMessageDialog(null, "No se pudo cerrar conexión " + e);
            }
        }
        
        System.out.println(rutas_list.size());
        return rutas_list;
    }
    
}
