package model_pkg;

import javax.sql.DataSource;
import org.apache.commons.dbcp.BasicDataSource;

/**
 *
 * @author estuam
 */
public class Pool {
    //Nombre de la Base de Datos ...
    private final String DB = "ciclismo_uam_db";
    private final String URL = "jdbc:mysql://localhost:3306/" + DB;
    private final String USER = "root";
    private final String PASSWORD = "";
    
    public DataSource initializeDataSource(){
        BasicDataSource inst_basicDataSource = new BasicDataSource();
        inst_basicDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
        inst_basicDataSource.setUrl(URL);
        inst_basicDataSource.setUsername(USER);
        inst_basicDataSource.setPassword(PASSWORD);
        return inst_basicDataSource;
    }
    
}
